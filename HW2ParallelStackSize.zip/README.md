Made using java 11

junit 4.10 and hamcrest 1.3 used for testing
jfreechart 1.0.19 and jcommon 1.0.23 for graphing
## Usage 

java -jar RossWagnerHW2ParallelStackSize.zip

This runs and plots the performance of the LockFreeStack class using various numbers of threads. 